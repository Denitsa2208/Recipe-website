﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Recipes_website.Models
{
    public class Recipie
    {
        public int Id { get; set; }
        public string Recipe { get; set; }
        public string HowToCook { get; set; }

        public bool IsFavorite { get; set; } 

        public Recipie()
        {

        }
    }
}
