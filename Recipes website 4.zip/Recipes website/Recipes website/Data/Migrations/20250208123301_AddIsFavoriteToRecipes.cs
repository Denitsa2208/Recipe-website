﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Recipes_website.Data.Migrations
{
    public partial class AddIsFavoriteToRecipes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsFavorite",
                table: "Recipie",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsFavorite",
                table: "Recipie");
        }
    }
}
