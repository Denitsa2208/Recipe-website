﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Recipes_website.Data;
using Recipes_website.Models;

namespace Recipes_website.Controllers
{
    public class RecipiesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RecipiesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Recipies
        public async Task<IActionResult> Index()
        {
            return View(await _context.Recipie.ToListAsync());
        }

        // GET: Recipies/ShowSearchForm
        public async Task<IActionResult> ShowSearchForm()
        {
            return View();
        }

        // PoST: Recipies/ShowSearcResults
        public async Task<IActionResult> ShowSearchResult(String Search)
        {
            return View(await _context.Recipie.Where(j=>j.Recipe.Contains(Search)).ToListAsync());
        }

        // GET: Recipies/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var recipie = await _context.Recipie
                .FirstOrDefaultAsync(m => m.Id == id);
            if (recipie == null)
            {
                return NotFound();
            }

            return View(recipie);
        }

        // GET: Recipies/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Recipies/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Recipe,HowToCook")] Recipie recipie)
        {
            if (ModelState.IsValid)
            {
                _context.Add(recipie);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(recipie);
        }

        // GET: Recipies/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var recipie = await _context.Recipie.FindAsync(id);
            if (recipie == null)
            {
                return NotFound();
            }
            return View(recipie);
        }

        // POST: Recipies/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Recipe,HowToCook")] Recipie recipie)
        {
            if (id != recipie.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(recipie);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RecipieExists(recipie.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(recipie);
        }

        // GET: Recipies/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var recipie = await _context.Recipie
                .FirstOrDefaultAsync(m => m.Id == id);
            if (recipie == null)
            {
                return NotFound();
            }

            return View(recipie);
        }

        // POST: Recipies/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var recipie = await _context.Recipie.FindAsync(id);
            _context.Recipie.Remove(recipie);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Favorites()
        {
            var favoriteRecipes = await _context.Recipie
                .Where(r => r.IsFavorite)
                .ToListAsync();
            return View(favoriteRecipes);
        }
        [HttpPost]
        public async Task<IActionResult> ToggleFavorite(int id)
        {
            var recipe = await _context.Recipie.FindAsync(id);
            if (recipe == null)
            {
                return NotFound();
            }

            // Toggle the IsFavorite property
            recipe.IsFavorite = !recipe.IsFavorite;
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }


        private bool RecipieExists(int id)
        {
            return _context.Recipie.Any(e => e.Id == id);
        }
    }
}
